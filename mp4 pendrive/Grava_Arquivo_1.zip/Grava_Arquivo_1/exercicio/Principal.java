class Principal
{
	public static void main (String args[])
	{
		Util.mostra("Entre com seu login");
		Util.pegasenha();
		if (x == "1")
		{
			Util.mostra ("senha correta");
		}
	}
}