class Util
{
	public static void mostra (String texto)
	{
		System.out.println(texto);
	}
	public static void pegasenha (String h)
	{
		String x=h;
	}
}